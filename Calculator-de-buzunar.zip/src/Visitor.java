/**
 * Interfata Visitor
 * @author Dorinela
 *
 */
public interface Visitor {
	
	/**
	 * @param p - nod de tipul OperatorPlus
	 */
	public void visit(OperatorPlus p);
	
	
	/**
	 * @param o - nod de tipul OperatorOri
	 */
	public void visit(OperatorOri o);
	
	
	/**
	 * @param m - nod de tipul OperatorMinus
	 */
	public void visit(OperatorMinus m);
	
	
	/**
	 * @param i - nod de tipul OperatorImpartire
	 */
	public void visit(OperatorImpartire i);
	
	
	/**
	 * @param rp - nod de tipul OperatorRidicarePutere
	 */
	public void visit(OperatorRidicarePutere rp);
	
	
	/**
	 * @param l - nod de tipul Logaritm
	 */
	public void visit(Logaritm l);
	
	
	/**
	 * @param r - nod de tipul Radical
	 */
	public void visit(Radical r);
	
	
	/**
	 * @param s - nod de tipul Sinus
	 */
	public void visit(Sinus s);
	
	
	/**
	 * @param c - nod de tipul Cosinus
	 */
	public void visit(Cosinus c);
	
	
	/**
	 * @param pd - nod de tipul ParantezaDeschisa
	 */
	public void visit(ParantezaDeschisa pd);
	
	
	/**
	 * @param pi - nod de tipul ParantezaInchisa
	 */
	public void visit(ParantezaInchisa pi);
	
	
	/**
	 * @param v - nod de tipul Valoare
	 */
	public void visit(Valoare v);


}
