/**
 * Clasa ce implementeaza interfata Visitor si calculeaza rezultatul
 * pentru fiecare tip de operator
 * @author Dorinela
 *
 */
public class Result implements Visitor{
	
	String s;

	/**
	 * Metoda ce viziteaza copii operatorului + si calculeaza rezultatul 
	 */
	@Override
	public void visit(OperatorPlus p) {
		// TODO Auto-generated method stub
		
		//vizitez primul copil si-l retin intr-o variabila
		p.childrens.get(0).accept(this);
		String s1 = s;
		
		//vizitez al doilea copil si-l retin intr-o variabila
		p.childrens.get(1).accept(this);
		String s2 = s;
		
		//calculez rezultatul
		double rez = Double.parseDouble(s1) + Double.parseDouble(s2);
		
		s = Double.toString(rez);
		
		
		
	}

	/**
	 * Metoda ce viziteaza copii operatorului * si calculeaza rezultatul 
	 */
	@Override
	public void visit(OperatorOri o) {
		// TODO Auto-generated method stub
		
		//vizitez primul copil si-l retin intr-o variabila
		o.childrens.get(0).accept(this);
		String s1 = s;
		
		//vizitez al doilea copil si-l retin intr-o variabila
		o.childrens.get(1).accept(this);
		String s2 = s;
		
		//calculez rezultatul
		double rez = Double.parseDouble(s1) * Double.parseDouble(s2);
		
		s = Double.toString(rez);
	
	}

	/**
	 * Metoda ce viziteaza copii operatorului - si calculeaza rezultatul 
	 */
	@Override
	public void visit(OperatorMinus m) {
		// TODO Auto-generated method stub
		
		//vizitez primul copil si-l retin intr-o variabila
		m.childrens.get(0).accept(this);
		String s1 = s;
		
		//vizitez al doilea copil si-l retin intr-o variabila
		m.childrens.get(1).accept(this);
		String s2 = s;
		
		//calculez rezultatul
		double rez = Double.parseDouble(s1) - Double.parseDouble(s2);
		
		s = Double.toString(rez);
		
	}

	/**
	 * Metoda ce viziteaza copii operatorului / si calculeaza rezultatul 
	 */
	@Override
	public void visit(OperatorImpartire i) {
		// TODO Auto-generated method stub
		
		//vizitez primul copil si-l retin intr-o variabila
		i.childrens.get(0).accept(this);
		String s1 = s;
		
		//vizitez al doilea copil si-l retin intr-o variabila
		i.childrens.get(1).accept(this);
		String s2 = s;
		
		//daca al doilea operand e 0 sau 0.0(pentru double), adica am impartire la 0, arunc exceptie
		if(s2.equals("0.0")){
			throw new EvaluatorException();
		}
		if(s2.equals("0")){
			throw new EvaluatorException();
		}
		
		//calculez rezultatul
		double rez = Double.parseDouble(s1) / Double.parseDouble(s2);
		
		s = Double.toString(rez);
		
		
	}

	/**
	 * Metoda ce viziteaza copii operatorului ^ si calculeaza rezultatul 
	 */
	@Override
	public void visit(OperatorRidicarePutere rp) {
		// TODO Auto-generated method stub
		
		//vizitez primul copil si-l retin intr-o variabila
		rp.childrens.get(0).accept(this);
		String s1 = s;
		
		//vizitez al doilea copil si-l retin intr-o variabila
		rp.childrens.get(1).accept(this);
		String s2 = s;
		
		//calculez rezultatul
		double rez = Math.pow(Double.parseDouble(s1), Double.parseDouble(s2));
		
		s = Double.toString(rez);
		
	}

	/**
	 * Metoda ce viziteaza copilul operatorului log si calculeaza rezultatul 
	 */
	@Override
	public void visit(Logaritm l) {
		// TODO Auto-generated method stub
		
		//vizitez copilul si-l retin intr-o variabila
		l.childrens.get(0).accept(this);
		String s1 = s;
		
		//daca am log(0) sau log(0.0)(pentru double) arunc exceptie
		if(s1.equals("0.0")){
			throw new EvaluatorException();
		}
		if(s1.equals("0")){
			throw new EvaluatorException();
		}
		
		//daca am logaritm din ceva negativ atunci arunc din nou exceptie
	    if(Double.parseDouble(s1) < 0){
	    	throw new EvaluatorException();
	    }
		
	    //calculez rezultatul
		double rez = Math.log10(Double.parseDouble(s1));

		s = Double.toString(rez);
		
	}

	
	/**
	 * Metoda ce viziteaza copilul operatorului sqrt si calculeaza rezultatul 
	 */
	@Override
	public void visit(Radical r) {
		// TODO Auto-generated method stub
		
		//vizitez copilul si-l retin intr-o variabila
		r.childrens.get(0).accept(this);
		String s1 = s;
		
		//daca am radical din ceva negativ, atunci arunc exceptie
		if(Double.parseDouble(s1) < 0){
	    	throw new EvaluatorException();
	    }
	
		//calculez rezultatul
		double rez = Math.sqrt(Double.parseDouble(s1));
		
		s = Double.toString(rez);
		
	}

	
	/**
	 * Metoda ce viziteaza copilul operatorului sin si calculeaza rezultatul 
	 */
	@Override
	public void visit(Sinus si) {
		// TODO Auto-generated method stub
		
		//vizitez copilul si-l retin intr-o variabila
		si.childrens.get(0).accept(this);
		String s1 = s;
		
		//calculez rezultatul
		double rez = Math.sin(Double.parseDouble(s1));
		
		s = Double.toString(rez);
		
	}

	
	/**
	 * Metoda ce viziteaza copilul operatorului cos si calculeaza rezultatul 
	 */
	@Override
	public void visit(Cosinus c) {
		// TODO Auto-generated method stub
		
		//vizitez copilul si-l retin intr-o variabila
		c.childrens.get(0).accept(this);
		String s1 = s;
		
		//calculez rezultatul
		double rez = Math.cos(Double.parseDouble(s1));
		
		s = Double.toString(rez);
		
	}

	/**
	 * Metoda pentru paranteza deschisa 
	 */
	@Override
	public void visit(ParantezaDeschisa pd) {
		// TODO Auto-generated method stub
		
	}

	
	/**
	 * Metoda pentru paranteza inchisa
	 */
	@Override
	public void visit(ParantezaInchisa pi) {
		// TODO Auto-generated method stub
		
		
	}

	
	/**
	 * Metoda pentru operanzi
	 */
	@Override
	public void visit(Valoare v) {
		// TODO Auto-generated method stub
		
		s = v.value;
		
	}
	
	/**
	 *
	 * @return rezultatul expresiei
	 */
	public float getResult(){
		
		float r1 = Float.parseFloat(s);

		return r1;
		
	}

}
