/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "/"
 * @author Dorinela
 *
 */
public class OperatorImpartire extends Node implements Visitable{
	
	/**
	 * constructor implicit
	 */
	public OperatorImpartire(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public OperatorImpartire(String s){
		super(s);
		tip = "neunar";//tipul operatorului neunar deoarece / are doi operanzi
	}

	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
}
