/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "-"
 * @author Dorinela
 *
 */
public class OperatorMinus extends Node implements Visitable{
	
	/**
	 * constructor implicit
	 */
	public OperatorMinus(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public OperatorMinus(String s){
		super(s);
		tip = "neunar";//tipul operatorului este neunar deoarece - are nevoie de 2 operanzi
	}

	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
