import java.io.IOException;
import java.util.Stack;

/**
 * Clasa in care creez arborele de parsare si calculez rezultatul asociat expresiei
 * @author Dorinela
 *
 */
public class ExpressionParser {
	
	/**
	 * Metoda in care creez arborele de parsare 
	 * @param expresie - expresia din care construiesc arborele de parsare
	 * @return - radacina arborelui
	 * @throws SyntacticException
	 */
	public Node CreareArbore(String expresie) throws SyntacticException{
		
		//initializarea celor 2 stive necesare pentru construirea arborelui de parsare
		Stack<Node> result_stack = new Stack<Node>();//stiva cu operanzi
		Stack<Node> operator_stack = new Stack<Node>();//stiva cu operatori
		
		int i;//variabila folosita pentru parcurgere
		
		//vector de stringuri in care retin elementele expresiei date
		String vector_initial[] = expresie.split("\\s+");
		
		
		/**
		 * daca expresia mea incepe cu - (exemplu: - sin ( 1 ) ) pun in fata operatorului - un 0
		  astfel obtin: 0 - sin ( 1 )
		  pentru a face acest lucru, am aces vector de Stringuri: vector_intermediar in care bag 
		  elementele vectorului initial + acest "0"
		 */
		String vector_intermediar[] = null;
		
		/**
		 * daca in expresie intalnesc ( - sin ( .....)) , adica dupa ce deschid paranteza am imediat "-"
		 * la fel ca mai sus introduc un "0"
		 * rezultatul in retin in vectorul "vector_final", cu acest vector construiesc mai departe arborele
		 */
		String vector_final[] = null;
		
		
		int j = 1;
		if(vector_initial[0].equals("-")){
			
			vector_intermediar = new String[vector_initial.length + 1];
			j = 0;
			vector_intermediar[0] = "0";
			for(i = 0; i < vector_initial.length; i++){
				j++;
				vector_intermediar[j] = vector_initial[i];
			}
		}
		else{
			vector_intermediar = new String[vector_initial.length];
			for(i = 0; i < vector_initial.length; i++){
				vector_intermediar[i] = vector_initial[i];
			}
		}
		int lungime = 0;
		for(i = 0; i < vector_intermediar.length - 1; i++){
			if(vector_intermediar[i].equals("(") && vector_intermediar[i+1].equals("-")){
				lungime ++;
			}
		}
		
		vector_final = new String[vector_intermediar.length + lungime];
		
		int k = 0;
		for(i = 0; i < vector_intermediar.length-1; i++){
			if(!vector_intermediar[i].equals("(")){
				vector_final[k] = vector_intermediar[i];
				k++;
			}else{
				if(vector_intermediar[i+1].equals("-")){
					vector_final[k] = "(";
					vector_final[k+1] = "0";
					vector_final[k+2] = vector_intermediar[i+1];
					k += 2;
				}
				else{
					vector_final[k] = vector_intermediar[i];
					k++;
				}
			}
		}
		
		vector_final[k] = vector_intermediar[vector_intermediar.length - 1];
		
		
		int nr_paranteza_d = 0;//numarul deparanteze deschise
		int nr_paranteza_i = 0;//numarul de paranteze inchise
		
		for(i = 0; i < vector_final.length; i++){
			//calculez numarul de paranteze deschise
			if(vector_final[i].equals("(")){
				nr_paranteza_d = nr_paranteza_d + 1;
			}
			
			//calculez numarul de paranteze inchise
			if(vector_final[i].equals(")")){
				nr_paranteza_i = nr_paranteza_i + 1;
			}
			
		}
		
	    //daca numarul parantelezor deschise nu este egal cunumarul parantezelor inchise atunciarunc exceptie
		if(nr_paranteza_d != nr_paranteza_i){
			throw new SyntacticException();
		}
		
		//parcurgere vector de String si construire arbore
		for(i = 0; i< vector_final.length; i++){
			
			//daca operatorul e +
			if(vector_final[i].equals("+")){
				
				//creez un obiect de tipul OperatorPlus
				OperatorPlus p = new OperatorPlus(vector_final[i]);
					
				//atata timp cat in capul stivei am un operator cu prioritate mai mare ca +
				while((operator_stack.size() > 0 && operator_stack.lastElement().value.equals("log")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("-")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("*")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("/")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("^")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sqrt")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sin")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("cos"))){
					
					//daca tipul e "neunar" calculez
					//agaug la copii operatorului cu prioritate mai mare elemente din stiva de operanzi(result_stack)
					if(operator_stack.lastElement().tip.equals("neunar")){
						operator_stack.lastElement().childrens.add(result_stack.pop());
						operator_stack.lastElement().childrens.addFirst(result_stack.pop());
						result_stack.push(operator_stack.pop());
					
					}
					
					//daca tipul e "unar" calculez
					//agaug la copii operatorului cu prioritate mai mare elemente din stiva de operanzi(result_stack)
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				//adaug operatorul + in stiva cu operatori
				operator_stack.push(p);
			}
			
			//la fel ca la operatorul +
			else if(vector_final[i].equals("-")){
				
				OperatorMinus m = new OperatorMinus(vector_final[i]);
				
				while((operator_stack.size() > 0 && operator_stack.lastElement().value.equals("log")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("-")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("*")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("/")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("^")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sin")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("cos")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sqrt"))){
					if(operator_stack.lastElement().tip.equals("neunar")){
					operator_stack.lastElement().childrens.add(result_stack.pop());
					operator_stack.lastElement().childrens.addFirst(result_stack.pop());
					result_stack.push(operator_stack.pop());
				    }
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				
				operator_stack.push(m);
			}
			
			//la fel ca la operatorul +
			else if(vector_final[i].equals("*")){
				OperatorOri o = new OperatorOri(vector_final[i]);
				
				
				while((operator_stack.size() > 0 && operator_stack.lastElement().value.equals("/")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("log")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sin")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("cos")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("^")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sqrt"))){
					if(operator_stack.lastElement().tip.equals("neunar")){
					operator_stack.lastElement().childrens.add(result_stack.pop());
					operator_stack.lastElement().childrens.addFirst(result_stack.pop());
					result_stack.push(operator_stack.pop());
					}
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				
				operator_stack.push(o);
			}
			
			//la fel ca la operatorul +
			else if(vector_final[i].equals("/")){
				OperatorImpartire im = new OperatorImpartire(vector_final[i]);
				
				while((operator_stack.size() > 0 && operator_stack.lastElement().value.equals("/")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("log")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sin")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("cos")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("^")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sqrt"))){
					if(operator_stack.lastElement().tip.equals("neunar")){
					operator_stack.lastElement().childrens.add(result_stack.pop());
					operator_stack.lastElement().childrens.addFirst(result_stack.pop());
					result_stack.push(operator_stack.pop());
					}
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				
				operator_stack.push(im);
			}
			
			//la fel ca la operatorul +
			else if(vector_final[i].equals("^")){
				OperatorRidicarePutere rp = new OperatorRidicarePutere(vector_final[i]);
				
				
				while((operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sqrt")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("log")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("sin")) || (operator_stack.size() > 0 && operator_stack.lastElement().value.equals("cos"))){
					if(operator_stack.lastElement().tip.equals("neunar")){
					operator_stack.lastElement().childrens.add(result_stack.pop());
					operator_stack.lastElement().childrens.addFirst(result_stack.pop());
					result_stack.push(operator_stack.pop());
					}
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				
				operator_stack.push(rp);
			}
			
			//daca elementul e log
			else if(vector_final[i].equals("log")){
				
				//creez un obiect de tipul Logaritm
				Logaritm ll = new Logaritm(vector_final[i]);
				
				//adaug in lista de operatori
				operator_stack.push(ll);
				
			}
			
			//daca elementul e sin
			else if(vector_final[i].equals("sin")){
				
				//creez un obiect de tipul Sinus
				Sinus si = new Sinus(vector_final[i]);
				
				//adaug in lista de operatori
				operator_stack.push(si);
			}
			
			//daca elementul e cos
			else if(vector_final[i].equals("cos")){
				
				//creez un obiect de tipul Cosinus
				Cosinus co = new Cosinus(vector_final[i]);
				
				//adaug in lista de operatori
				operator_stack.push(co);
			}
			
			//daca elementul e sqrt
			else if(vector_final[i].equals("sqrt")){
			
					//creez un obiect de tipul Radical
					Radical radical = new Radical(vector_final[i]);
					
					//adaug in lista de operatori
					operator_stack.push(radical);
					
			}
			
			//daca elementul e (
			else if(vector_final[i].equals("(")){
		        
				//creez un obiect de tipul ParantezaDeschisa
				ParantezaDeschisa pd = new ParantezaDeschisa(vector_final[i]);
				
				//adaug in lista de operatori
				operator_stack.push(pd);
				
			}
			
			//daca elementul e )
			else if(vector_final[i].equals(")")){
				
				//creez un obiect de tipul ParantezaInchisa
				ParantezaInchisa pi = new ParantezaInchisa(vector_final[i]);
				
				//incep sa scot din stiva cu operatori
				//atata timp cat nu intalnesc ( calculez
				while(operator_stack.lastElement().value.equals("(") == false){
					
					if(operator_stack.lastElement().tip.equals("neunar")){
						operator_stack.lastElement().childrens.add(result_stack.pop());
						operator_stack.lastElement().childrens.addFirst(result_stack.pop());
						result_stack.push(operator_stack.pop());
						
					}
					else{
						operator_stack.lastElement().childrens.add(result_stack.pop());
						result_stack.push(operator_stack.pop());
					}
				}
				
				//adaug in lista de operatori
				operator_stack.pop();
			}
			
			//daca elementul e ++ runc exceptie
			else if(vector_final[i].equals("++")){
				throw new SyntacticException(); 
			}
			
			//daca elementul e -- runc exceptie
			else if(vector_final[i].equals("--")){
				throw new SyntacticException(); 
			}
			
			//altfel am un operand
			else{
				
					//creez un obiect de tipul Valoare
					Valoare v = new Valoare(vector_final[i]);
					
					//adaug in stiva de operanzi(result_stack)
					result_stack.push(v);
			}	
			
		}
		
		/**
		 * daca stiva de operanzi e goalaarunc exceptie
		 */
		if (result_stack.empty()) { throw new SyntacticException(); }
		
		//golesc stivele si calculez
		if(operator_stack.lastElement().tip.equals("unar")){
			
			operator_stack.lastElement().childrens.add(result_stack.pop());
			result_stack.push(operator_stack.pop());
		
	    }
	
		while(result_stack.size() > 1 && operator_stack.size() > 0){
			
			operator_stack.lastElement().childrens.add(result_stack.pop());
			operator_stack.lastElement().childrens.addFirst(result_stack.pop());
			result_stack.push(operator_stack.pop());
				
			}
			
		return result_stack.pop();
		
	}
	
	/**
	 * 
	 * @param expression - xpresia de calculat
	 * @return - rezultatul expresiei
	 * @throws SyntacticException
	 * @throws EvaluatorException
	 */
	public float eval(String expression) throws SyntacticException, EvaluatorException{
		// do the magic
		
		Node r = new Node();
		
		r = CreareArbore(expression);//creez arborele
		Result result = new Result();
	
		r.accept(result);
		float rezultat_final = result.getResult();//rezultatul expresiei
		
		return rezultat_final;
		
		
	}
	
}
