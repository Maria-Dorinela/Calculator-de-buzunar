/**
 * Clasa Cosinus care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "cos"
 * @author Dorinela
 *
 */
public class Cosinus extends Node implements Visitable{
	
	/**
	 * constructor implicit
	 */
	public Cosinus(){
		
	}
	
	/**
	 * Constructor cu un parametru de tip String
	 * @param s
	 */
	public Cosinus(String s){
		super(s);
		tip = "unar";//tipul operatorului unar deoarece cos primeste un singur operand
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
