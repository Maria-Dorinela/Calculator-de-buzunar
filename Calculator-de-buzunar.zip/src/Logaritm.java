/**
 * Clasa Logaritm care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "log"
 * @author Dorinela
 *
 */
public class Logaritm extends Node implements Visitable{
	
	/**
	 * constructor implicit
	 */
	public Logaritm(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public Logaritm(String s){
		super(s);
		tip = "unar";///tipul operatorului unar deoarece log primeste un singur operand
	}

	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
