import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Clasa Node
 * @author Dorinela
 *
 */
public class Node implements Visitable{
	
	
	public String value;//valoarea din nod
	LinkedList<Node> childrens = new LinkedList<Node>();//copii unui nod
	public String tip;//tipul valorii dintr-un nod
	
	/**
	 * constructor implicit
	 */
	public Node(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 */
	public Node(String s){
		
		this.value = s;
		
	}
	
	/**
	 * Metoda ce afisaza arborele creat
	 */
	 public void preorder() {
        
		 System.out.println(value);
         for (int i=0; i<childrens.size(); i++) {
        	 
                 childrens.get(i).preorder(); 
         }
 }
	 

	@Override
	public void accept(Visitor v) {
		// TODO Auto-generated method stub
		
	}

}
