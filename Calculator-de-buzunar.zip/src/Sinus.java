/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "sin"
 * @author Dorinela
 *
 */
public class Sinus extends Node implements Visitable{

	/**
	 * constructor implicit
	 */
	public Sinus(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public Sinus(String s){
		super(s);
		tip = "unar";//tipul operatorului este unar deoarece sin are nevoie de un singur operand
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
