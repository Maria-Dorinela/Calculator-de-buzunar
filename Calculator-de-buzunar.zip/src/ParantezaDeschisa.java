/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru ")"
 * @author Dorinela
 *
 */
public class ParantezaDeschisa extends Node implements Visitable{

	/**
	 * constructor implicit
	 */
	public ParantezaDeschisa(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public ParantezaDeschisa(String s){
		super(s);
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
