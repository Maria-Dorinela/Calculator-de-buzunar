/**
 * Interfata Visitable
 * @author Dorinela
 *
 */
public interface Visitable {
	
	/**
	 * 
	 * @param v - variabila de tipul Visitor
	 */
	 public void accept(Visitor v);
	 
}
