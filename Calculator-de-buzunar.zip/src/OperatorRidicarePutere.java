/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "^"
 * @author Dorinela
 *
 */
public class OperatorRidicarePutere extends Node implements Visitable{

	/**
	 * constructor implicit
	 */
	public OperatorRidicarePutere(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public OperatorRidicarePutere(String s){
		super(s);
		tip = "neunar";//tipul operatorului este neunar deoarece ^ are nevoie de 2 operanzi
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
