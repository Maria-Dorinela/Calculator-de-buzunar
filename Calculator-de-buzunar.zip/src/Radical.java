/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru operatorul "sqrt"
 * @author Dorinela
 *
 */
public class Radical extends Node implements Visitable{
	
	/**
	 * constructor implicit
	 */
	public Radical(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public Radical(String s){
		super(s);
		tip = "unar";//tipul operatorului este unar deoarece sqrt are nevoie de un singur operand
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }

}
