/**
 * Clasa OperatorImpartire care extinde clasa Node si implementeaza interfata Visitable
 * Folosita pentru "("
 * @author Dorinela
 *
 */
public class ParantezaInchisa extends Node implements Visitable{

	/**
	 * constructor implicit
	 */
	public ParantezaInchisa(){
		
	}
	
	/**
	 * constructor cu un parametru de tip String
	 * @param s
	 */
	public ParantezaInchisa(String s){
		super(s);
	}
	
	@Override
    public void accept(Visitor v) {
		
            v.visit(this);
       
    }
	
}
