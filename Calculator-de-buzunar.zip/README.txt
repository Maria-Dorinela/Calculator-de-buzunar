	
	Sirbu Maria-Dorinela, 332CB
	Teama 4 - POO: Calculator de buzunar
	
Pentru implementarea acestei teme am utilizat Pattern-ul Visitor

Tema contine:
	
	- Interfetele Visitor si Visitable
	- Clase pentru fiecare element din expresie: OperatorPlus, Sinus, Cosinus, ParantezaDeschisa,.....;
	- Clasa EvaluatorException din scheletul de cod
	- Clasa SyntacticException din scheletul de cod
	- Clasa Result ce implementeaza interfata  Visitor si calculeaza pentru fiecare tip de operator rezultatul(viziteaza copii fiecarui operator)
	- Clasa ExpresionParser ce contine metodele:
				- CreareArbore care creaza arborele de parsare
				- eval ce returneaza rezultatul expresiei
				
	In cod am pus comentarii in care am explicat ce am facut.